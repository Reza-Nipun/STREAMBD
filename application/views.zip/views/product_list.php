<div class="pull-left breadcrumb_admin clear_both">
        <div class="pull-left page_title theme_color">
          <h1>Product Inventory</h1>
          <h2 class="">Product Inventory...</h2>
        </div>
        <div class="pull-right">
          <ol class="breadcrumb">
              <li><a href="<?php echo base_url();?>">Home</a></li>
              <li class="active">Product Inventory</li>
          </ol>
        </div>
      </div>
      <div class="container clear_both padding_fix">
        <!--\\\\\\\ container  start \\\\\\-->
        <div class="row">
        <div class="col-md-12">
          <div class="block-web">
            <div class="header">
              <div class="actions"> <a class="minimize" href="#"><i class="fa fa-chevron-down"></i></a> <a class="refresh" href="#"><i class="fa fa-repeat"></i></a> <a class="close-down" href="#"><i class="fa fa-times"></i></a> </div>
              <h3 class="content-header">Product List</h3>
            </div>
              <?php if($access_level == 1){ ?>
                <a class="btn btn-success" href="<?php echo base_url();?>access/add_new_product">+ Add Product</a><br />
              <?php } ?>
              <div style="padding-top:10px">
                  <h6 style="color:red">
                      <?php
                      $exc = $this->session->userdata('exception');
                      if (isset($exc)) {
                          echo $exc;
                          $this->session->unset_userdata('exception');
                      }
                      ?>
                  </h6>

                  <h6 style="color:green">
                      <?php
                      $msg = $this->session->userdata('message');
                      if (isset($msg)) {
                          echo $msg;
                          $this->session->unset_userdata('message');
                      }
                      ?>
                  </h6>
              </div>

       <div class="porlets-content">
         <sec class="table-responsive">
             <section class="panel default blue_title h2">

                 <div class="panel-body">

                 <table class="display table table-bordered table-striped" id="dynamic-table">
                   <thead>
                    <tr>
                      <th class="hidden-phone center">Product Code</th>
                      <th class="hidden-phone center">Brand</th>
                      <th class="hidden-phone center">Category</th>
                      <th class="hidden-phone center">Item</th>
                      <th class="hidden-phone center">Size</th>
                  <?php if($access_level == 1){ ?>
                      <th class="hidden-phone center">Purchase Date</th>
                      <th class="hidden-phone center">Purchase Price</th>
                  <?php } ?>
                      <th class="hidden-phone center">Sale Price</th>
<!--                      <th class="hidden-phone center">Picture</th>-->
                      <th class="hidden-phone center">Status</th>
                  <?php if($access_level == 1){ ?>
                      <th class="hidden-phone center">Shop</th>
                  <?php } ?>
                      <th class="hidden-phone center">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php foreach ($products as $v){?>
                    <tr>
                        <td class="center"><?php echo $v['product_code'];?></td>
                        <td class="center"><?php echo $v['brand_name'];?></td>
                        <td class="center"><?php echo $v['category_name'];?></td>
                        <td class="center"><?php echo $v['item_name'];?></td>
                        <td class="center"><?php echo $v['size'];?></td>
                    <?php if($access_level == 1){ ?>
                        <td class="center"><?php echo $v['purchase_date'];?></td>
                        <td class="center"><?php echo $v['purchase_price'];?></td>
                    <?php } ?>
                        <td class="center"><?php echo $v['sale_price'];?></td>
<!--                        <td class="center">--><?php //echo $v['picture_url'];?><!--</td>-->
                        <td class="center">
                            <?php
                            if($v['status'] == 1){
                                echo "Active";
                            }
                            if($v['status'] == 0){
                                echo "Inactive";
                            }
                            ?>
                        </td>
                    <?php if($access_level == 1){ ?>
                        <td class="hidden-phone center"><?php echo $v['shop'];?></td>
                    <?php } ?>
                        <td class="center">
                            <?php
                            if($access_level == 1){
                            if($v['status'] == 0){ ?>
                                <a href="<?php echo base_url();?>access/updateProductStatus/<?php echo $v['id']?>/1" class="btn btn-success" style="cursor: pointer;">Active</a>
                            <?php } ?>
                            <?php if($v['status'] == 1){ ?>
                                <a href="<?php echo base_url();?>access/updateProductStatus/<?php echo $v['id']?>/0" class="btn btn-danger" style="cursor: pointer;">Inactive</a>
                            <?php } ?>
                            <a target="_blank" href="<?php echo base_url();?>access/print_sticker/<?php echo $v['product_code'];?>" class="btn btn-warning" style="cursor: pointer;">Print Sticker</a>
                            <?php } ?>
                        </td>
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
             </section>
              </div>
              </div>
              </div>
              </div>

           </div>